// Import the validation function
const { validateDonationForm } = require('./Script');

describe("Donation Form Validation", () => {
    test("Valid input should pass validation", () => {
        const validData = { charityName: "Charity A", donationAmount: 50, donationDate: "2024-11-28" };
        expect(validateDonationForm(validData)).toBe(true);
    });

    test("Missing charity name should fail validation", () => {
        const invalidData = { charityName: "", donationAmount: 50, donationDate: "2024-11-28" };
        expect(validateDonationForm(invalidData)).toBe(false);
    });

    test("Donation amount of 0 should fail validation", () => {
        const invalidData = { charityName: "Charity A", donationAmount: 0, donationDate: "2024-11-28" };
        expect(validateDonationForm(invalidData)).toBe(false);
    });

    test("Missing donation date should fail validation", () => {
        const invalidData = { charityName: "Charity A", donationAmount: 50, donationDate: "" };
        expect(validateDonationForm(invalidData)).toBe(false);
    });

    test("Negative donation amount should fail validation", () => {
        const invalidData = { charityName: "Charity A", donationAmount: -10, donationDate: "2024-11-28" };
        expect(validateDonationForm(invalidData)).toBe(false);
    });
});
